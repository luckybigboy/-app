// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

// ajax
import axios from 'axios'
import VueAxios from 'vue-axios'
Vue.use(VueAxios, axios);

// 状态管理
import Vuex from 'vuex';
Vue.use(Vuex);

// ui库

Vue.config.productionTip = false

// 引入store
import store from './store/index'

// 全局（局部使用vant组件）
import {
  Dialog
} from 'vant'

//全局使用自定义指令
Vue.directive('red', {
  inserted(el, binding) {
    el.style.color = binding.arg;
  }
})

// 图片懒加载
import Vuelazyload from 'vue-lazyload';
Vue.use(Vuelazyload);


// 全局前置守卫
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.requireAuth)) {
    if (!sessionStorage.getItem('token') && !localStorage.getItem('token')) {
        Dialog.confirm({
          title: '警告',
          message: '登录后，才能访问...'
        }).then(() => {
          next({
            path: '/login',
            query: {redirect: to.fullPath} 
          })
        }).catch( () => {
          
        })
    } else {
      next();
    }
  } else {
    next();
  }
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: {
    App
  },
  template: '<App/>'
})
