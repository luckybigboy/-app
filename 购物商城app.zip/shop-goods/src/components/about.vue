<template>
  <div id="about">
    about
  </div>
</template>
<script>
  export default {
    name: 'about',
    data() {
      return {

      }
    }
  }

</script>
<style scoped lang='less'></style>
