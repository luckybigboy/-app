<template>
  <div id="swiper">
      <van-row>
         <van-col span='24'>
            <van-swipe :autoplay="3000">
                <van-swipe-item v-for="(image, index) in images" :key="index">
                    <img v-lazy="image" style="width: 100%;height: 160px" />
                  </van-swipe-item>
              </van-swipe>
         </van-col>
      </van-row>
  </div>
</template>
<script>
  import { Swipe, SwipeItem, Row, Col} from 'vant';
  import { mapState } from 'vuex'
  export default {
    name: 'swiper',
    data() {
      return {
        images: []
      }
    },
    props: {
      tapItem: {
        type: String,
        required: true
      }
    },
    computed: {
      ...mapState({
        dImgSrc: state => state.home.lunboImg.imgSrc
      })
    },
    components: {
      [Swipe.name]: Swipe,
      [SwipeItem.name]: SwipeItem,
      [Row.name]: Row,
      [Col.name]:Col
    },
    beforeCreate() {
      this.axios.get('../../static/data.json').then(res => {

        if(res.status == 200) {
           const data = res.data.home.lunbo;
           switch(this.tapItem) {
             case "今日推荐": this.images = data.home; break;
             case "美妆": this.images = data.meizhuang; break;
             case "家电": this.images = data.jiadian; break;
             case "家居": this.images = data.jiaju; break;
             case "国际": this.images = data.guoji; break;
             case "生活": this.images = data.shenghuo; break;
             default: this.images = this.dImgSrc; break;
           }
        } else {
          this.images = this.dImgSrc;
        } 
      },(err) => {
        this.images = this.dImgSrc;
      })
    },
    created() {
      console.log(this.tapItem);
    }
  }

</script>
<style scoped lang='less'></style>
