<template>
  <div id="news"></div>
</template>
<script>
  export default {
    name: 'news',
    data() {
      return {

      }
    }
  }

</script>
<style scoped lang='less'></style>
