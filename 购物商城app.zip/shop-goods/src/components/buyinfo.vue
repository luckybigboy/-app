<template>
  <div id="buyinfo"></div>
</template>
<script>
  export default {
    name: 'buyinfo',
    data() {
      return {

      }
    }
  }

</script>
<style scoped lang='less'></style>
