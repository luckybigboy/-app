<template>
  <div id="community">
    <app-header></app-header>
    <ul class="nav">
      <li v-for="(item, index) in navList" :key="item.id" :class="{'actived': defaultIndex === index}"
        @click="choose(index)">
        {{item}}
      </li>
    </ul>
    <ul class="content">
      <li v-if="defaultIndex===0">
        <div v-for="(item, index) in commentList" :key="item.id">
          <div class="contents">
            <div class="left">
              <img :src="item.headImg" alt="">
              <span>{{item.title}}</span>
            </div>
            <div class="right" @click="show=true">
              <span>. . .</span>
            </div>
          </div>
          <div class="main_header">
            <span>{{item.mainTitle}}</span>
            <span>{{item.sawTimes}}</span>
          </div>
          <div class="main_img">
            <img :src="item.mainImg" alt="">
          </div>
          <div class="instroduceTitle">
            {{item.instroduceTitle}}
          </div>
        </div>
      </li>
      <li v-if="defaultIndex===1">1</li>
      <li v-if="defaultIndex===2">2</li>
    </ul>
    <app-taBar></app-taBar>
    <van-action-sheet v-model="show" :actions="actions" @select="onSelect" />
  </div>
</template>
<script>
  import {
    Toast,
    ActionSheet
  } from 'vant'
  export default {
    name: 'community',
    data() {
      return {
        navList: ['动态', '热门', '发现'],
        defaultIndex: 0,
        show: false,
        actions: [{
            name: '转发',
            color: "#5c86d2"
          },
          {
            name: '发送给好友',
            color: "#5c86d2"
          },
          {
            name: '取消分享',
            color: "#5c86d2"
          }
        ],
        commentList: [{
            headImg: 'https://b.vimage1.com/upload/mst/2018/06/11/53/0bb659b137130f45de936fce60f99431_604x290_80.jpg',
            title: '热门内容.来自:A.B.C',
            mainTitle: '新人专享',
            sawTimes: '浏览602次',
            mainImg: 'https://b.vimage1.com/upload/mst/2018/06/11/53/0bb659b137130f45de936fce60f99431_604x290_80.jpg',
            instroduceTitle: '随着服装款式设计的风格各式各样，人们对穿衣的质量及风格有了很高的追求，于是和商家类目选择都带来一定的影响，根据目前春夏季类目划分里，几个比较有争议的话题就是根据目前春夏季类目划分里，几个比较有争议的话题就是'
          },
          {
            headImg: 'https://b.vimage1.com/upload/mst/2018/06/11/53/0bb659b137130f45de936fce60f99431_604x290_80.jpg',
            title: '热门内容.来自:A.B.C',
            mainTitle: '新人专享',
            sawTimes: '浏览602次',
            mainImg: 'https://a.vimage1.com/upcb/2018/06/07/39/ias_152837250337311_604x290_80.jpg',
            instroduceTitle: '随着服装款式设计的风格各式各样，人们对穿衣的质量及风格有了很高的追求，于是和商家类目选择都带来一定的影响，根据目前春夏季类目划分里，几个比较有争议的话题就是根据目前春夏季类目划分里，几个比较有争议的话题就是'
          },
        ]
      }
    },
    methods: {
      choose(index) {
        this.defaultIndex = index;
      },
      onSelect(item) {
        this.show = false;
      }
    },
    components: {
      [Toast.name]: Toast,
      [ActionSheet.name]: ActionSheet,
      "app-taBar": resolve => require(['../components/publicComponents/tabBar'], resolve),
      "app-header": resolve => require(['../components/publicComponents/header'], resolve)
    },
    mounted() {
      Toast('一起发现更大的世界(*^▽^*)');
    }
  }

</script>
<style scoped lang='less'>
  @import url('../assets/css/community.less');
</style>
