<template>
  <div id="active">
    <!-- 活动组件 -->
    <van-row>
      <van-col span="24" class="col-2">
        <h4>{{titleArr[0]}}</h4>
      </van-col>
    </van-row>
    <!-- 图片瀑布流 -->
    <div class="lazys" v-waterfall-lower="loadMore" water-disabled="disabled" water-offset="300" name="lazy">
      <van-row v-for="(item, index) in imgList" :key="index">
        <img v-lazy="item" alt="" name="adapter" class="dImg">
        <van-col span="18" offset="2" class="activeTitle">
          <h4>{{activeTitle[index]}}</h4>
        </van-col>
        <van-col span="4" class="daysTitle"><span>剩余{{days[index]}}天</span></van-col>
      </van-row>
    </div>
  </div>
</template>
<script>
  import {
    Row,
    Col,
    Lazyload
  } from 'vant';
  import Waterfall from '@vant/waterfall';
  import {
    mapState
  } from 'vuex';
  export default {
    name: 'active',
    data() {
      return {
        imgList: [],
        activeTitle: null,
        days: null,
        disabled: false
      }
    },
    methods: {
      // 瀑布流
      loadMore() {
        this.disabled = true;
        setTimeout(() => {
          for (let i = 0; i < 6; i++) {
            if (this.imgList.length > 0) {
              this.imgList.push(this.imgList[i]);
              this.activeTitle.push(this.activeTitle[i]);
              this.days.push(this.days[i]);
            }
          }
          this.disabled = false;
        }, 300)
      }
    },
    props: {
      tapItem: {
        type: String,
        required: true
      }
    },
    computed: {
      ...mapState({
        titleArr: state => state.active.home.title,
        defaultImg: state => state.home.lunboImg.imgSrc
      })
    },
    components: {
      [Row.name]: Row,
      [Col.name]: Col,
      [Lazyload.name]: Lazyload
    },
    directives: {
      //瀑布流
      WaterfallLower: Waterfall('lower')
    },
    created() {
      this.axios.get('../../static/data.json').then(res => {
        if (res.status === 200) {
          const data = res.data.home;
          this.days = data.active.days;
          const titleArr = data.active;
          switch (this.tapItem) {
            case "今日推荐":
              this.imgList = data.imageList;
              this.activeTitle = titleArr.tuijian_title;
              break;
            case "时尚":
              this.imgList = data.shishangImglist;
              this.activeTitle = titleArr.shishang_title;
              break;
            case "美妆":
              this.imgList = data.meizhuangImglist;
              this.activeTitle = titleArr.meizhuang_title;
              break;
            case "家电":
              this.imgList = data.jiadianImglist;
              this.activeTitle = titleArr.jiadian_title;
              break;
            case "家居":
              this.imgList = data.jiajuImglist;
              this.activeTitle = titleArr.jiaju_title;
              break;
            case "国际":
              this.imgList = data.guojiImglist;
              this.activeTitle = titleArr.guoji_title;
              break;
            case "生活":
              this.imgList = data.shenghuoImglist;
              this.activeTitle = titleArr.shenghuo_title;
              break;
            default:
              this.imgList = this.defaultImg;
              break;
          }
        } else {
          this.imgList = this.defaultImg;
        }
      }, err => {
        this.imgList = this.defaultImg;
      })
    },
    beforeCreate() {

    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/home.less");

</style>
