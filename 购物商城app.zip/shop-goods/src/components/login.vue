<template>
  <div id="login">
    <div class="loginBox">
      <img src="../../static/images/welcome.png" alt="" class="welcome">
      <div class="userName commonStyle">
        <label for="userName">
          用户名
        </label>
        <input type="text" class="ipt"  v-model.trim="userName" placeholder="请输入用户名" maxlength="16" minlength="4">
      </div>
      <div class="passWord commonStyle">
        <label for="userName">
          密码
        </label>
        <input type="password" class="ipt" v-model.trim="passWord" placeholder="请输入密码">
      </div>
      <div class="commonStyle btn" @click="login">
        <span>{{btnTitle}}</span>
      </div>
      <div class="regAndfogPwd">
        <a href="#" @click="toRegister('/register')">立即注册</a>|<a href="#">忘记密码?</a>
      </div>
    </div>
  </div>
</template>
<script>
  import {
    mapGetters,
    mapMutations
  } from 'vuex';
  import {
    Toast
  } from 'vant';
  export default {
    name: 'login',
    data() {
      return {
        userName: '',
        passWord: '',
        btnTitle: '立即登录'
      }
    },
    computed: {
      // count() {
      //     return this.$store.state.count;
      // }

      //另一种方式获取值
      // ...mapGetters([
      //     'getCount',
      //     'getListArr'
      // ]),
      // getListArr1() {
      //     return this.$store.getters.getListArr('marry');
      // },
      // getListFilters() {
      //     return this.$store.getters.getListFilter('marry');
      // }
    },
    components: {
      [Toast.name]: Toast
    },
    methods: {
      // 登录
      login() {
        if (!this.userName || !this.passWord) {
          Toast('请输入相关信息');
        } else if (this.userName !== 'bigbigbug' || this.passWord !== 'W123') {
          Toast('用户名或密码不正确');
        } else {
          let params = {
            userName: this.userName,
            pwd: this.passWord
          }
          // this.axios.post('../../static/data.json', params).then(res => {
          //   console.log(res);
          // })
          this.axios.get('../../static/login.json').then(res => {
            if(res.status === 200) {
              // 废弃， 测试使用
              this.$router.push({name: 'home', query: { sucLogin: true }});
              // this.$router.push('/home');
              localStorage.setItem('token', res.data.login.token);
            }
          }).catch(err => {
            throw err;
          })
        }
      },
      // 立即注册
      toRegister(url) {
        this.$router.push(url);
      }

    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/login.less");

</style>
