<template>
  <div id='home'>
    <!-- 搜索区 -->
    <app-header></app-header>
    <!-- 内容区域 -->
    <van-row class="tops">
      <van-col span="24">
        <van-tabs v-model='active'>
          <van-tab v-for="index in 7" :title="tabTitle[index]" :key="index.id">
            <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
              <!-- 今日推荐模块 -->
              <div v-if="tabTitle[index] == '今日推荐'" class="container">
                <swiper :tapItem="tabTitle[index]" class="swiper"></swiper>
                <van-row class="col-2">
                  <van-col span='6' class="row-2" v-for="(item, index) in iconImg" :key="item">
                    <a href="#" @click="tips">
                      <img :src="iconPath+item+'.png'" alt="">
                      <span>{{iconTitle[index]}}</span>
                    </a>
                  </van-col>
                  <!-- 通知 -->
                  <van-col span="24" class="boardCast">
                    <van-notice-bar class="boardCastTitle" mode="closeable" :text="boardCastTitle" :scrollable="true"
                      left-icon="https://img.yzcdn.cn/public_files/2017/8/10/6af5b7168eed548100d9041f07b7c616.png">
                    </van-notice-bar>
                  </van-col>

                  <!-- 活动 -->
                  <active :tapItem="tabTitle[index]"></active>
                </van-row>
              </div>
              <!-- 时尚模块 -->
              <div v-if="tabTitle[index] == '时尚'" class="container">
                <!-- 活动 -->
                <active :tapItem="tabTitle[index]"></active>
              </div>
              <!-- 美妆模块 -->
              <div v-if="tabTitle[index] == '美妆'" class="container">
                <swiper :tapItem="tabTitle[index]"></swiper>
                <active :tapItem="tabTitle[index]"></active>
              </div>
              <!-- 家电模块 -->
              <div v-if="tabTitle[index] == '家电'" class="container">
                <swiper :tapItem="tabTitle[index]"></swiper>
                <active :tapItem="tabTitle[index]"></active>
              </div>
              <!-- 家居模块 -->
              <div v-if="tabTitle[index] == '家居'" class="container">
                <swiper :tapItem="tabTitle[index]"></swiper>
                <active :tapItem="tabTitle[index]"></active>
              </div>
              <!-- 国际模块 -->
              <div v-if="tabTitle[index] == '国际'" class="container">
                <swiper :tapItem="tabTitle[index]"></swiper>
                <active :tapItem="tabTitle[index]"></active>
              </div>
              <!-- 生活模块 -->
              <div v-if="tabTitle[index] == '生活'" class="container">
                <swiper :tapItem="tabTitle[index]"></swiper>
                <active :tapItem="tabTitle[index]"></active>
              </div>
            </van-pull-refresh>
          </van-tab>
        </van-tabs>
      </van-col>
    </van-row>

    <!-- 底部导航 -->
    <taBar></taBar>
  </div>
</template>
<script>
  import {
    Icon,
    Search,
    Row,
    Col,
    Tabs,
    Tab,
    PullRefresh,
    Toast,
    NoticeBar,
    Dialog
  } from 'vant';
  import {
    mapState
  } from 'vuex';
  export default {
    name: "home",
    data() {
      return {
        active: 0,
        isLoading: false,
        iconPath: '../../static/images/icon/',
        loginTitle: '登录'
      }
    },
    created() {
      this.checkLogin();
    },
    computed: {
      // loginTitle() {
      //     return localStorage.getItem('token') ? '已登录' : '登录';
      // }
    },
    methods: {
      // 判断是否已登录
      checkLogin() {
        this.loginTitle = localStorage.getItem('token') ? '已登录' : '登录';
      },
      toPage(url) {
        const tokenValue = localStorage.getItem('token');
        if (!tokenValue) {
          this.$router.push(url);
        } else {
          Dialog.confirm({
            title: '警告',
            message: '是否退出登录',
            closeOnClickOverlay: true
          }).then(() => {
            this.$router.push(url);
            localStorage.removeItem('token');
          }).catch(() => {
            // on cancel
          });
        }
      },
      // 下拉刷新
      onRefresh() {
        setTimeout(() => {
          this.$toast('刷新成功');
          this.isLoading = false;
        }, 500);
      },
      tips() {
        this.$toast('功能还在开发中, 抱歉！！！');
      },

      // 搜索
      search() {
        this.$router.push('/search');
      }
    },
    computed: {
      ...mapState({
        tabTitle: state => state.home.tab.title,
        iconImg: state => state.home.iconfonts.iconImg,
        iconTitle: state => state.home.iconfonts.iconTitle,
        boardCastTitle: state => state.home.boardCast
      })
    },
    components: {
      [Icon.name]: Icon,
      [Search.name]: Search,
      [Row.name]: Row,
      [Col.name]: Col,
      [Tab.name]: Tab,
      [Tabs.name]: Tabs,
      [PullRefresh.name]: PullRefresh,
      [Toast.name]: Toast,
      [NoticeBar.name]: NoticeBar,
      [Dialog.name]: Dialog,
      // 组件按需加载
      taBar: resolve => require(['../components/publicComponents/tabBar'], resolve),
      swiper: resolve => require(['../components/swiper'], resolve),
      active: resolve => require(['../components/active'], resolve),
      "app-header": resolve => require(['../components/publicComponents/header'], resolve)
    }
  }

</script>
<style lang="less" scoped>
  @import url("../assets/css/home.less");
</style>
