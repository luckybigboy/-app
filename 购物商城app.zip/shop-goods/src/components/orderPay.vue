<template>
  <div id="orderPay"></div>
</template>
<script>
  export default {
    name: 'orderPay',
    data() {
      return {

      }
    }
  }

</script>
<style scoped lang='less'></style>
