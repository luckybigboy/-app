<template>
  <div id="me">
    <h2 class="txtCenter">我的</h2>
    <div class="defaultMsg">
      <div class="left">
        <van-uploader :after-read="afterRead" :max-count="1" :disabled="isDisabled">
          <img :src="deafultImg" alt="">
        </van-uploader>
        <span @click="toPage('/login')">{{title}}</span>
      </div>
      <div class="center">
        <img src="../../static/images/icon/camera.png" alt="">
      </div>
      <div class="right"></div>
    </div>
    <ul class="meList">
      <li @click="chooseList(1)">我的信用评分</li>
      <li @click="chooseList(2)">物流信息</li>
      <li @click="chooseList(3)">联系人管理</li>
      <li @click="chooseList(4)">密码设置</li>
      <li>
        安全模式
        <van-switch class="switch" size="20px" :value="checked" @input="securityMode()" active-color="#07c160"
          inactive-color="#ee0a24" />
      </li>
    </ul>
    <div class="circle">
      <van-circle v-model="currentRate" size="120" color="#e425a9" layer-color="#eee" :rate="30" :speed="100"
        :text="text" />
      <p>今日运势</p>
    </div>
    <app-tabBar></app-tabBar>
    <!-- 信用评分弹框 -->
    <van-overlay :show="show" @click="show = false">
      <div class="wrapper" :class="{'bgPwd': chooseIndex===4}" @click.stop>
        <div class="block" v-if="chooseIndex===1">
          <h3>我的信用评分</h3>
          <p class="p1">100分</p>
          <p class="tip">本月表现绝佳，小主人再接再厉</p>
        </div>
        <div class="block" v-if="chooseIndex===2">
          <h3>物流信息</h3>
          <van-steps :active="active" class="textL">
            <van-step>买家下单</van-step>
            <van-step>商家接单</van-step>
            <van-step>买家提货</van-step>
            <van-step>交易完成</van-step>
          </van-steps>
          <van-steps direction="vertical" :active="active">
            <van-step v-for="(item, index) in logistics" :key="item.id">
              <h3 :class="{'goodsl': active == index}">{{item.details}}</h3>
              <p :class="{'goodsl txtCenter fz12': active == index}">{{item.time | translteTime}}</p>
            </van-step>
          </van-steps>
        </div>
        <div class="block" v-if="chooseIndex===3">
          <h3>联系人管理</h3>
          <div class="addConcat" @click="addConcat">
            <van-icon name="add-o" class="icon1" /> 添加订单联系人信息
            <van-icon name="arrow" class="icon2" />
          </div>
          <p class="tip bottoms">保存联系人联系方式 能够有效的与他人取得联系哦--</p>
        </div>
        <div class="block" v-if="chooseIndex===4">
          <h3>密码设置</h3>
          <!-- 密码输入框 -->
          <van-password-input :value="value" info="密码为 6 位数字" :focused="showKeyboard" @focus="showKeyboard = true" />
          <!-- 数字键盘 -->
          <van-number-keyboard :show="show" theme="custom" extra-key="." close-button-text="完成" @blur="sure"
            @input="onInput($event)" @delete="onDelete" />
          <p class="tip">请小主人妥善保管好密码哦--</p>
        </div>
      </div>
    </van-overlay>
    <van-action-sheet v-model="shows" title="添加联系人">
      <div class="addUserConcat">
        <van-icon name="add-o" class="icon1" /> 新建联系人
        <van-icon name="arrow" class="icon2" />
      </div>
      <div class="circle">
        <van-circle v-model="currentRate" size="120" color="#e425a9" layer-color="#eee" :rate="30" :speed="100"
          :text="text" />
        <p>今日运势</p>
      </div>
    </van-action-sheet>
  </div>
</template>
<script>
  import {
    Switch,
    Circle,
    Dialog,
    Uploader,
    Toast,
    Overlay,
    PasswordInput,
    NumberKeyboard,
    Step,
    Steps,
    Icon,
    ActionSheet
  } from 'vant'
  export default {
    name: 'me',
    data() {
      return {
        checked: true,
        currentRate: 0,
        title: null,
        isDisabled: true,
        show: false,
        shows: false,
        chooseIndex: null,
        value: '',
        showKeyboard: true,
        isPwd: true,
        active: 0,
        deafultImg: '../../static/images/icon/defaultHead.png',
        logistics: [{
            details: '【武汉市】 快件已到菜鸟驿站请带好证件来取件',
            time: '1575610431468',
          },
          {
            details: '【无锡市】 已到无锡集散中心正准备发往下一站',
            time: '1572611033049',
          },
          {
            details: '快件已发货',
            time: '1575110733019',
          }
        ]
      }
    },
    methods: {
      toLogin(tokenValue, url) {
        if (!tokenValue) {
          this.$router.push(url);
        } else {
          Dialog.confirm({
            title: '警告',
            message: '是否退出登录',
            closeOnClickOverlay: true
          }).then(() => {
            localStorage.removeItem('token');
            // localStorage.removeItem('deafultImgs');
            this.deafultImg = "../../static/images/icon/defaultHead.png";
            this.title = "立即登录";
          }).catch(() => {
            // on cancel
          });
        }
      },
      toPage(url) {
        const tokenValue = localStorage.getItem('token');
        this.toLogin(tokenValue, url);
      },
      // 上传图片
      afterRead(file) {
        if (file.content) {
          this.deafultImg = file.content;
          localStorage.setItem('deafultImgs', file.content);
          setTimeout(() => {
            Toast('图片上传成功ヾ(^∀^)ﾉ');
          }, 500)
        } else {
          Toast('图片上传失败(╯﹏╰)b');
        }
      },
      chooseList(num) {
        this.show = !this.show;
        switch (num) {
          case 1:
            this.chooseIndex = 1;
            break;
          case 2:
            this.chooseIndex = 2;
            break;
          case 3:
            this.chooseIndex = 3;
            break;
          case 4:
            this.chooseIndex = 4;
            break;
          default:
            this.chooseIndex = null;
            break;
        }
      },
      onInput(key) {
        this.value = (this.value + key).slice(0, 6);
      },
      onDelete() {
        this.value = this.value.slice(0, this.value.length - 1);
      },
      sure() {
        let len = this.value.length;
        if (len === 6) {
          if (this.isPwd) {
            Toast('密码设置成功');
            this.isPwd = false;
          }
        } else {
          this.value = '';
        }
        this.show = false;
      },
      securityMode(checked) {
        Dialog.confirm({
          title: '提醒',
          message: '关闭安全模式可能给您带来风险，是否确认关闭'
        }).then(() => {
          this.checked = false;
        }).catch(() => {
          this.checked = true;
        });
      },
      // 添加联系人
      addConcat() {
        this.shows = true;
      }
    },
    computed: {
      text() {
        return this.currentRate.toFixed(0) + '分';
      }
    },
    created() {

    },
    mounted() {
      if (localStorage.getItem('token')) {
        this.title = "已登录";
        if (localStorage.getItem('deafultImgs')) {
          this.deafultImg = localStorage.getItem('deafultImgs');
        }
        this.isDisabled = false;
      } else {
        this.title = "立即登录";
      }
    },
    components: {
      [Switch.name]: Switch,
      [Circle.name]: Circle,
      [Dialog.name]: Dialog,
      [Uploader.name]: Uploader,
      [Toast.name]: Toast,
      [Overlay.name]: Overlay,
      [PasswordInput.name]: PasswordInput,
      [NumberKeyboard.name]: NumberKeyboard,
      [Step.name]: Step,
      [Steps.name]: Steps,
      [Icon.name]: Icon,
      [ActionSheet.name]: ActionSheet,
      'app-tabBar': resolve => require(['../components/publicComponents/tabBar'], resolve)
    },
    filters: {
      translteTime(timestamp) {
        let date;
        if (timestamp.length === 10) {
          date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
        } else {
          date = new Date(timestamp * 1);
        }
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        return Y + M + D + h + m + s;
      }
    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/me.less");

</style>
