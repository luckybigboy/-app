<template>
  <div id="home">
    <van-row span='24' class="row-1">
      <van-col span='3' class="cols">
        <a href="#" @click.prevent="toPage('/search')">返回</a>
      </van-col>
      <van-col span="18" class="cols txtCenter">
        <span>{{title}}</span>
      </van-col>
      <van-col span="3"></van-col>
    </van-row>
    <!-- 商品列表 -->
    <van-pull-refresh v-model="isLoading" @refresh="onRefresh">
      <div class="over">
        <van-row v-for="(img,index) in goodsListImg.img1" :key='img.id' class="lists">
          <van-col span='11' offset="1">
            <div class="imgs" @click="toPage('orderList', index, true)">
              <img v-lazy="img" alt="">
            </div>
            <p class="title">{{titleListArr.title1[index]}}</p>
            <p class="prc">￥{{limitPriceArr.prc1[index]}}
              <span>￥{{originPriceArr.prc1[index]}}</span><span>{{discountListArr.dis1[index]}}折</span></p>
          </van-col>
          <van-col span="11" offset="1">
            <div class="imgs" @click="toPage('orderList', index, false)">
              <img v-lazy="goodsListImg.img2[index]" alt="">
            </div>
            <p class="title">{{titleListArr.title1[index]}}</p>
            <p class="prc">￥{{limitPriceArr.prc1[index]}}
              <span>￥{{originPriceArr.prc1[index]}}</span><span>{{discountListArr.dis1[index]}}折</span></p>
          </van-col>
        </van-row>
        <div class="txtCenter bottom">
            <van-divider :style="{ color: '#1989fa', borderColor: '#1989fa', padding: '0 16px' }">
                我可是有底线的
              </van-divider>
        </div>
      </div>
    </van-pull-refresh>
  </div>
</template>
<script>
  import {
    Row,
    Col,
    PullRefresh,
    Toast,
    Lazyload,
    Divider
  } from 'vant';
  import Waterfall from '@vant/waterfall';
  export default {
    name: 'goodsInfo',
    data() {
      return {
        title: null,
        isLoading: false,
        goodsListImg: {
          img1: [],
          img2: []
        },
        titleListArr: {
          title1: [],
          title2: []
        },
        discountListArr: {
          dis1: [],
          dis2: []
        },
        limitPriceArr: {
          prc1: [],
          prc2: []
        },
        originPriceArr: {
          prc1: [],
          prc2: []
        }
      }
    },
    components: {
      [Row.name]: Row,
      [Col.name]: Col,
      [PullRefresh.name]: PullRefresh,
      [Toast.name]: Toast,
      [Lazyload.name]: Lazyload,
      [Divider.name]: Divider
    },
    methods: {
      toPage(url, index) {
        let params = {
          imgs: this
        }
        this.$router.push(url);
      },
      // 下拉刷新
      onRefresh() {
        setTimeout(() => {
          this.$toast('刷新成功');
          this.isLoading = false;
        }, 500);
      },
      // 跳转详情页
      toPage(url, index, bool) {
        let params = {};
        if (bool) {
          params.img = this.goodsListImg.img1[index];
          params.limitPrc = this.limitPriceArr.prc1[index];
          params.originPrc = this.originPriceArr.prc1[index];
          params.discountPrc = this.discountListArr.dis1[index];
          params.title = this.titleListArr.title1[index];
        } else {
          params.img = this.goodsListImg.img2[index];
          params.limitPrc = this.limitPriceArr.prc2[index];
          params.originPrc = this.originPriceArr.prc2[index];
          params.discountPrc = this.discountListArr.dis2[index];
          params.title = this.titleListArr.title2[index];
        }
        this.$router.push({
          name: url,
          query: {
            parma: params
          }
        });
      }
    },
    created() {
      this.title = this.$route.query.itemName;
      // 获取数据
      this.axios.get('../../static/data.json').then(res => {
        if (res.status === 200) {
          const data = res.data.goods;
          let id = this.$route.query.id;
          if (id) {
            this.goodsListImg.img1 = data[id].imgList[0];
            this.goodsListImg.img2 = data[id].imgList[1];
            this.titleListArr.title1 = data[id].title[0];
            this.titleListArr.title2 = data[id].title[1];
            this.discountListArr.dis1 = data[id].discount[0];
            this.discountListArr.dis2 = data[id].discount[1];
            this.limitPriceArr.prc1 = data[id].limit_price[0];
            this.limitPriceArr.prc2 = data[id].limit_price[1];
            this.originPriceArr.prc1 = data[id].original_price[0];
            this.originPriceArr.prc2 = data[id].original_price[1];
          }
        }
      }).catch(err => {
        throw err;
      })
    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/home.less");
  @import url("../assets/css/goods.less");

</style>
