<template>
  <div id="login">
      <div class="loginBox">
        <span class="return"
              @click="toPages('/login')">
          <img src="../../static/images/icon/返回键 (1).png"
               alt="">
        </span>
        <img src="../../static/images/welcome.png"
             alt=""
             class="welcome">
        <div class="userName commonStyle">
          <label for="userName">
            用户名
          </label>
          <input type="text"
                 class="ipt"
                 v-model.trim="userName"
                 placeholder="请输入用户名"
                 @blur="checkValue(userName, 'user')"
                 maxlength="16"
                 minlength="4">
        </div>
        <div class="passWord commonStyle">
          <label for="userName">
            密码
          </label>
          <input type="password"
                 class="ipt"
                 v-model.trim="passWord"
                 placeholder="请输入密码"
                 @blur="checkValue(passWord, 'pwd')">
        </div>
        <div class="passWord commonStyle">
          <label for="userName">
            确认密码
          </label>
          <input type="password"
                 class="ipt"
                 v-model.trim="surePassWord"
                 placeholder="请输入密码"
                 @blur="checkValue(surePassWord, 'spwd')">
        </div>
        <div class="commonStyle">
          <label for="userName">
            手机号码
          </label>
          <input type="number"
                 placeholder="请输入手机号码"
                 v-model.trim="phone"
                 class="phone">
          <button class="code"
                @click="getCodes" :disabled="isBtnClick">{{getCode}}</button>
        </div>
        <div class="commonStyle">
          <van-password-input class="codeBox"
                              :value="value"
                              :length="4"
                              :gutter="15"
                              :focused="showKeyboard"
                              @focus="showKeyboard = true" />
          <!-- 数字键盘 -->
          <van-number-keyboard class="keycode"
                               :show="showKeyboard"
                               @input="onInput"
                               @delete="onDelete"
                               @blur="showKeyboard = false" />
        </div>
        <div class="commonStyle btn"
             @click="registers">
          <span>{{btnTitle}}</span>
        </div>
      </div>
  </div>
</template>
<script>
import { mapGetters, mapMutations } from 'vuex';
import { Toast, PasswordInput, NumberKeyboard, Dialog  } from 'vant';
export default {
  name: 'register',
  data () {
    return {
      userName: '',
      passWord: '',
      surePassWord: '',
      phone: '',
      btnTitle: '立即注册',
      getCode: '获取验证码',
      isCheck: false,
      isUser: false,
      isPwd: false,
      isSpwd: false,
      isPhone: false,
      showKeyboard: false,
      isClick: true,
      isBtnClick:false,
      value: '',
      time: 60
    }
  },
  computed: {

  },
  components: {
    [Toast.name]: Toast,
    [PasswordInput.name]: PasswordInput,
    [NumberKeyboard.name]: NumberKeyboard,
    [Dialog.name]: Dialog
  },
  methods: {
    // 检测输入值
    checkValue (iptValue, iptName) {
      if (iptName === 'user') {
        const userReg = /^\w{4,16}$/ig;
        if (!userReg.test(iptValue)) {
          this.isCheck = true;
          if (this.isCheck) {
            setTimeout(() => {
              Toast('请输入4到16位(字母,数字,下划线)');
              this.isCheck = false;
            }, 500);
          }
        } else {
          this.isUser = true;
        }
      } else if (iptName === 'pwd') {
        const pwdReg = /([A-Z]{1,2}\w{6,10})/g;
        if (!pwdReg.test(iptValue)) {
          setTimeout(() => {
            Toast('请输入7到12位(字母,数字,下划线)且必须包含一个大写字母');
          }, 500);
        } else {
          if (pwdValue.length < 10) {
            setTimeout(() => {
              Toast('密码强度 较弱');
            }, 500);
            this.isPwd = true;
          } else {
            setTimeout(() => {
              Toast('密码强度 安全');
            }, 500);
            this.isPwd = true;
          }
        }
      } else if (iptName === 'spwd') {
        if (iptValue !== this.passWord)
          Toast('两次输入的密码必须一致')
        else
          this.isSpwd = true;
      }
    },
    // 注册
    registers () {
      if (!this.userName || !this.passWord) {
        Toast('请输入相关信息');
      } else if (this.isUser && this.isPwd && this.isSpwd) {
        console.log('注册');
      }
    },
    // 返回登录页
    toPages (url) {
      this.$router.push(url);
    },
    // 获取验证码
    getCodes () {
      const phoneReg = /^1[3-9][0-9]{9}$/g;
      if (!phoneReg.test(this.phone)) {
        Toast('请输入正确的手机号');
      } else {
        let param = {
          "phone": this.phone,
          "tpl_id": "200508",
          "key": "2654adddc698cc0916b9fdf8bbb8fffa"
        };
        if (this.isClick) {
          this.isCheck = false;
          this.isBtnClick = true;
          let timer = null;
          this.axios.post('/apis/', param).then(res => {
            timer = setInterval(() => {
              this.time--;
              this.getCode = this.time + 's后重新获取';
              if (this.time <= 0) {
                this.getCode = '获取验证码';
                this.time = 60;
                clearInterval(timer);
                this.isCheck = true;
                this.isBtnClick = false;
              }
            }, 1000)
          })
        }
      }
    },
    onInput (key) {
      this.value = (this.value + key).slice(0, 6);
    },
    onDelete () {
      this.value = this.value.slice(0, this.value.length - 1);
    }
  },
  beforeRouteLeave(to, from, next) {
    Dialog.confirm({
      title: '提示',
      message: '你确定要退出注册？'
    }).then(() => {
       next();
    }).catch(() => {

    })
  }
}
</script>
<style scoped lang='less'>
@import url("../assets/css/login.less");
</style>