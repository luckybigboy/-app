<template>
  <div id="headers">
    <!-- 搜索区 -->
    <div class="tops">
      <div class="leftTitle" @click="toPage('/login')">
        {{loginTitle}}
      </div>
      <div class="center">
        <form action="/">
          <van-search class="search" style="background:white;height:35px;border-radius:22px;" placeholder="大家在搜索：衣服"
            @click.stop='search' />
        </form>
      </div>
      <div class="rightIcon">
        <van-icon name="qr" class="classfic" @click="toPage('/about', true)"></van-icon>
      </div>
    </div>
  </div>
</template>
<script>
  import {
    Icon,
    Search,
    Row,
    Col,
    Dialog
  } from 'vant';
  export default {
    name: 'headers',
    data() {
      return {
        loginTitle: '登录'
      }
    },
    components: {
      [Icon.name]: Icon,
      [Search.name]: Search,
      [Row.name]: Row,
      [Col.name]: Col,
      [Dialog.name]: Dialog
    },
    created() {
      this.checkLogin();
    },
    methods: {
      // 判断是否已登录
      checkLogin() {
        this.loginTitle = localStorage.getItem('token') ? '已登录' : '登录';
      },
      toPage(url) {
        const tokenValue = localStorage.getItem('token');
        if (!tokenValue) {
          this.$router.push(url);
        } else {
          Dialog.confirm({
            title: '警告',
            message: '是否退出登录',
            closeOnClickOverlay: true
          }).then(() => {
            this.$router.push(url);
            localStorage.removeItem('token');
          }).catch(() => {
            // on cancel
          });
        }
      },

      // 搜索
      search() {
        this.$router.push('/search');
      }
    }
  }

</script>
<style lang="less" scoped>
  @import url('../../assets/publicCss/headers.less');

</style>
