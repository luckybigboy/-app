<template>
  <div id="notFound">
    <div>
        <img src="../../../static/images/404.png" alt="" class="notFoundImg">
    </div>
    <span class="return" @click="toPage('/home')">返回首页...</span>
  </div>
</template>
<script>
  export default {
    name: 'notFound',
    data() {
      return {

      }
    },
    methods: {
        toPage(url) {
            this.$router.push(url);
        }
    }
  }

</script>
<style lang="less">
    #notFound {
        text-align: center;
        width: 100%;
    }
    .notFoundImg {
        width: 80%;
        margin-top: 30%;
        margin-bottom: 10%;
    }
   .return {
       font-size: 20px;
       color: #b3a7a7;
   }
</style>
