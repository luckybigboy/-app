<template>
  <div id="tabBar">
    <van-tabbar v-model="active" route class="tabBar">
      <van-tabbar-item icon="home-o" to="/home" replace>首页</van-tabbar-item>
      <van-tabbar-item icon="comment-o" dot to="/community">社区</van-tabbar-item>
      <van-tabbar-item icon="shopping-cart-o" :info="shop_cart" to="/shoppingCart">购物车</van-tabbar-item>
      <van-tabbar-item icon="manager-o" :info="my_info" to="/me">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>
<script>
  import {
    Tabbar,
    TabbarItem,
    Icon
  } from 'vant';
  import {
    mapState
  } from 'vuex';
  export default {
    name: 'tabBar',
    data() {
      return {
        active: 0
      }
    },
    methods: {

    },
    computed: {
      ...mapState({
        shop_cart: state => state.home.shop_cart,
        my_info: state => state.home.my_info
      })
    },
    components: {
      [Tabbar.name]: Tabbar,
      [TabbarItem.name]: TabbarItem,
      [Icon.name]: Icon
    }
  }

</script>
<style lang="less">
  .tabBar {
    border-top: 1px solid #efefef;
    height: 60px;
  }

</style>
