<template>
  <div id="home">
    <!-- 搜索区 -->
    <app-header></app-header>
    <app-taBar></app-taBar>
  </div>
</template>
<script>
  import { 
    Icon,
    Search,
    Row,
    Col}
    from 'vant';
  export default {
    name: 'shoppingCart',
    data() {
      return {
        loginTitle: '登录'
      }
    },
    components: {
      [Icon.name]: Icon,
      [Search.name]: Search,
      [Row.name]: Row,
      [Col.name]: Col,
      "app-taBar": resolve => require(['../components/publicComponents/tabBar'], resolve),
      "app-header": resolve => require(['../components/publicComponents/header'], resolve)
    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/home.less");
</style>
