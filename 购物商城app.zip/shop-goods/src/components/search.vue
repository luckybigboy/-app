<template>
  <div id="home">
    <van-row class="row-1" gutter="20">
      <van-col span='3' class="cols">
        <a href="#" @click.prevent="toPage('/home')">返回</a>
      </van-col>
      <van-col span="19" class="cols">
        <form action="/">
          <van-search class="search" style="background:white;height:35px;border-radius:22px;" placeholder="衣服"
            @keydown.enter.prevent="search" @keypress.stop="showOrHide" @input="searchItem" v-model="value" />
        </form>
      </van-col>
      <van-col span="2" class="cols">
        <van-icon name="qr" class="classfic" @click="toPage('/about')"></van-icon>
      </van-col>
    </van-row>
    <van-row v-show="show && !getSearchArr.length">
      <!-- 历史搜索 -->
      <van-row v-if="oldSearchArr.length">
        <van-row class="searchBox">
          <van-col span="20">
            历史搜索
          </van-col>
          <van-col span="4" style="text-align: center" @click.stop="clearSearch">
            <van-icon name="delete"></van-icon>
          </van-col>
        </van-row>
        <ul class="chooseTitle">
          <li v-for="(item) in oldSearchArr" :key="item" class="choose">
            {{item}}
          </li>
        </ul>
      </van-row>
      <!-- 热门搜索 -->
      <van-row class="searchBox">
        <van-col span="20">
          热门搜索
        </van-col>
        <van-col span="4" style="text-align: center" @click.stop="closeEye">
          <img v-show="isEye" :src="path+`/eye.png`" alt="">
          <img v-show="!isEye" :src="path+`/anticon.png`" alt="">
        </van-col>
      </van-row>
      <van-row v-show="!isEye" style="text-align: center; font-size: 10px;color: #ddd">
        <van-col span="24">当前搜索发现已隐藏</van-col>
      </van-row>
      <ul class="chooseTitle" v-show="isEye">
        <li v-for="(item) in titleArr" :key="item" class="choose" @click="hotSearch(item)">
          {{item}}
        </li>
      </ul>
    </van-row>
    <!-- 搜索内容 -->
    <van-row v-if="getSearchArr.length" class="searchItem">
      <van-col span="24" v-for="item in getSearchArr" :key="item" class="line" @click="searchItems(item, $event)">
            {{item}}
      </van-col>
    </van-row>
  </div>
</template>
<script>
  import {
    Row,
    Col,
    Icon,
    Search,
    Dialog
  } from 'vant';
  export default {
    name: 'search',
    data() {
      return {
        titleArr: ['羽绒毛', '围巾', '面膜', '护肤', '衣服', '女靴', '口红'],
        oldSearchArr: [],
        show: true,
        value: "衣服",
        isEye: true,
        path: '../../static/images/icon',
        getSearchArr: []
      }
    },
    methods: {
      toPage(url) {
        this.$router.push(url);
      },
      // 搜索
      search() {
        this.axios.get("../../static/data.json").then(res => {
          if(res.status === 200) {
             let data = res.data.searchArr;
             this.getSearchArr = data.cowMilk;
          }
        }).catch(err => {
          throw err;
        })
      },
      showOrHide() {
        // !this.value ? this.show = true : this.show = false;
      },
      closeEye() {
        this.isEye = !this.isEye;
      },
      // 删除历史搜索
      clearSearch() {
        Dialog.confirm({
          title: '提示',
          message: '确定删除全部的历史记录？'
        }).then(() => {
           this.oldSearchArr = [];
           this.value = "";
        }).catch(() => {
          // on cancel
        });
      },
      
      // 搜索无数据时， 清空内容
      searchItem() {
         if(this.value === "") 
         this.getSearchArr = [];  
      },
      // 点击搜索项添加到历史搜索
      searchItems(v, event) {
        if(this.oldSearchArr.indexOf(v) === -1)
        this.oldSearchArr.push(v);
        this.getSearchArr = [];
        this.$router.push({name: 'goodsInfo', query: {itemName: v, id: 'id_0'}});
      },
      // 热门搜索
      hotSearch(item) {
        this.value = item;
      }
    },
    components: {
      [Row.name]: Row,
      [Col.name]: Col,
      [Icon.name]: Icon,
      [Search.name]: Search,
      [Dialog.name]: Dialog
    }
  }

</script>
<style scoped lang='less'>
  @import url("../assets/css/home.less");
</style>
