import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
// const store = new Vuex.Store({
//   state: {
//     count: 0,
//     listArr: [{
//         id: 0,
//         name: 'marry',
//         age: 20
//       },
//       {
//         id: 1,
//         name: 'kity',
//         age: 22
//       },
//       {
//         id: 2,
//         name: 'lucy',
//         age: 21
//       }
//     ]
//   },
//   mutations: {
//     add: (state, params) => {
//       state.count++;
//       console.log(params);
//     },
//     subtract: (state, params) => {
//       state.count--;
//       console.log(params);
//     },
//     changeCount(state, params) {
//       state.count++;
//       console.log(params);
//     },
//   },
//   getters: {
//     getCount(state) {
//       return state.count;
//     },
//     getListArr: (state) => (v) => {
//       return state.listArr.find(item => item.name === v);
//     },
//     getListFilter: (state) => (v) => {
//         return state.listArr.filter(item => item.name == v);
//     }
//   }
// })
// 导入对应的store模块
import home from './modules/home';
import active from './modules/active';

const store = new Vuex.Store({
  modules: {
    home: home,
    active: active
  }
})

export default store;
