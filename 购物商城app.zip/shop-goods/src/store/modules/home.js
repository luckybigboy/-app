export default {
  state: {
    tab: {
      title: ['', '今日推荐', '时尚', '美妆', '家电', '家居', '国际', '生活']
    },
    lunboImg: {
      imgSrc: ['../../../static/images/lunbo/err.jpg', '../../../static/images/lunbo/err.jpg', '../../../static/images/lunbo/err.jpg']
    },
    iconfonts: {
      iconImg: ['icon_1', 'icon_2', 'icon_8', 'icon_4', 'icon_5', 'icon_6', 'icon_7', 'icon_10'],
      iconTitle: ['鞋包馆', '运动馆', '母婴馆', '超市', '女装馆', '美妆馆', '男装馆', '更多']
    },
    boardCast: "今日特卖 每天早10点 晚8点上新  今日特卖 每天早10点 晚8点上新  今日特卖 每天早10点 晚8点上新",
    shop_cart: 4,
    my_info: 2
  },
  mutations: {

  },
  actions: {

  },
  getters: {

  }
}