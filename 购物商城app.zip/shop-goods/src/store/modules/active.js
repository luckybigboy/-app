export default {
  state: {
    home: {
      title: ['今日特卖 · 每天早10点 晚8点上新', '运动休闲男女专场', '剩2天20小时'],
      activeTitle: [],
      days: []
    }
  }
}
