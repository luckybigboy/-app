import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home';
// import Login from '@/components/login';
// import Register from '@/components/register';
// import About from '@/components/about';
// import Community from '@/components/community';
// import ShoppingCart from '@/components/shoppingCart';
// import Me from '@/components/me';
// import Search from '@/components/search';
// import notFound from '@/components/publicComponents/notFound';


Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: Home
    },
    {
      path: '/home',
      name: 'home',
      component: Home
      // component: resolve => require(['../components/home.vue'],resolve)
    },
    {
      path: '/login',
      name: 'login',
      // component: Login
      component: resolve => require(['../components/login.vue'], resolve)
    },
    {
      path: '/register',
      name: 'register',
      // component: Register,
      // 路由懒加载
      component: resolve => require(['../components/register.vue'], resolve)
    },
    {
      path: '/about',
      name: 'about',
      // component: About
      component: resolve => require(['../components/about.vue'], resolve)
    },
    {
      path: '/community',
      name: 'community',
      // component: Community,
      component: resolve => require(['../components/community.vue'], resolve),
      meta: {
        title: '社区',
        requireAuth: true
      }
    },
    {
      path: '/shoppingCart',
      name: 'shoppingCart',
      // component: ShoppingCart,
      component: resolve => require(['../components/shoppingCart.vue'], resolve),
      meta: {
        title: '购物车',
        requireAuth: true
      }
    },
    {
      path: '/me',
      name: 'me',
      // component: Me,
      component: resolve => require(['../components/me.vue'], resolve),
      // meta: {
      //   title: '我的',
      //   requireAuth: true
      // }
    },
    {
      path: '/search',
      name: 'search',
      // component: Search
      component: resolve => require(['../components/search.vue'], resolve),
    },
    {
      path: '/goodInfo',
      name: 'goodsInfo',
      component: resolve => require(['../components/goodsinfo.vue'], resolve),
      meta: {
        title: '商品列表',
        requireAuth: true
      }
    },
    {
      path: '/orderList',
      name: 'orderList',
      component: resolve => require(['../components/orderList.vue'], resolve),
      meta: {
        title: '商品详情',
        requireAuth: true
      }
    },
    {
      path: '*',
      name: 'notFound',
      // component: notFound
      component: resolve => require(['../components/publicComponents/notFound.vue'], resolve)
    }
  ],
  mode: "history"
})
