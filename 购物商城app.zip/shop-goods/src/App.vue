<template>
  <div id="app">
      <transition name="fade">
         <keep-alive include="search">
            <router-view></router-view>
         </keep-alive>
      </transition>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
    }
  }
}
</script>

<style lang="less">

#app {
  height: 100vh;
  /* overflow-y: hidden; */
  overflow-x: hidden;
  /* font-size: 0.625rem; */
}
.fade-enter-active{
  transition: all .3s ease;
}
 .fade-leave-active {
  transition: all .5s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  /* transform: translateX(10px); */
  opacity: 0;
}
@import url('./assets/publicCss/public.less');
</style>
