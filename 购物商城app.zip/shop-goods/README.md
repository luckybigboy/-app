# shop-goods

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# 发送短信文件sms-send(语言node) 
cnpm run serve 


# 申明（此项目是自己在业余时间写的，为了学习vue, 有些模块的功能还未实现，后期会完善。）
```


For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
